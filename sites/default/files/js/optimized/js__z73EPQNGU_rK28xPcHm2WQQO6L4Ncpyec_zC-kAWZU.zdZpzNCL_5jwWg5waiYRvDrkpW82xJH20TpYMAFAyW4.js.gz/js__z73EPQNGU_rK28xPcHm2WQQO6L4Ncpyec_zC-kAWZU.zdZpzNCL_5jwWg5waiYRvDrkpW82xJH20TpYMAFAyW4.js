/* Source and licensing information for the line(s) below can be found at http://tht-react.dd:8083/themes/TH_base2/js/build/scripts.js. */
"use strict";!function(n,o){n.behaviors.TH_base2={attach:function(n,i){o(window).on("load",function(){}),o(window).on("resize",function(){}),o(window).on("scroll",function(){})}}}(Drupal,jQuery);
//# sourceMappingURL=scripts.js.map

/* Source and licensing information for the above line(s) can be found at http://tht-react.dd:8083/themes/TH_base2/js/build/scripts.js. */